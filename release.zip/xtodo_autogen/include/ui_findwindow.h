/********************************************************************************
** Form generated from reading UI file 'findwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDWINDOW_H
#define UI_FINDWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_findwindow
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_6;
    QLabel *findLabel;
    QLineEdit *findEdit;
    QHBoxLayout *horizontalLayout_7;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *findwindow)
    {
        if (findwindow->objectName().isEmpty())
            findwindow->setObjectName(QString::fromUtf8("findwindow"));
        findwindow->resize(200, 50);
        QIcon icon;
        icon.addFile(QString::fromUtf8("icon.ico"), QSize(), QIcon::Normal, QIcon::Off);
        findwindow->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(findwindow);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        findLabel = new QLabel(findwindow);
        findLabel->setObjectName(QString::fromUtf8("findLabel"));
        QFont font;
        font.setFamily(QString::fromUtf8("Monospace"));
        findLabel->setFont(font);

        horizontalLayout_6->addWidget(findLabel);

        findEdit = new QLineEdit(findwindow);
        findEdit->setObjectName(QString::fromUtf8("findEdit"));

        horizontalLayout_6->addWidget(findEdit);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        buttonBox = new QDialogButtonBox(findwindow);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(false);

        horizontalLayout_7->addWidget(buttonBox);


        verticalLayout->addLayout(horizontalLayout_7);


        retranslateUi(findwindow);
        QObject::connect(buttonBox, SIGNAL(accepted()), findwindow, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), findwindow, SLOT(reject()));

        QMetaObject::connectSlotsByName(findwindow);
    } // setupUi

    void retranslateUi(QDialog *findwindow)
    {
        findwindow->setWindowTitle(QCoreApplication::translate("findwindow", "Find", nullptr));
        findLabel->setText(QCoreApplication::translate("findwindow", "Find:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class findwindow: public Ui_findwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDWINDOW_H
