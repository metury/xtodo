/********************************************************************************
** Form generated from reading UI file 'editwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITWINDOW_H
#define UI_EDITWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_editwindow
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_6;
    QLabel *priorityLabel;
    QLineEdit *priorEdit;
    QHBoxLayout *horizontalLayout_5;
    QLabel *complDateLabel;
    QLineEdit *complDateEdit;
    QHBoxLayout *horizontalLayout_4;
    QLabel *creatDateLabel;
    QLineEdit *createDateEdit;
    QHBoxLayout *horizontalLayout_3;
    QLabel *textLabel;
    QLineEdit *textEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *contextLabel;
    QLineEdit *contextEdit;
    QHBoxLayout *horizontalLayout;
    QLabel *projectLabel;
    QLineEdit *projectEdit;
    QHBoxLayout *horizontalLayout_7;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *editwindow)
    {
        if (editwindow->objectName().isEmpty())
            editwindow->setObjectName(QString::fromUtf8("editwindow"));
        editwindow->resize(494, 275);
        QIcon icon;
        icon.addFile(QString::fromUtf8("icon.ico"), QSize(), QIcon::Normal, QIcon::Off);
        editwindow->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(editwindow);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        priorityLabel = new QLabel(editwindow);
        priorityLabel->setObjectName(QString::fromUtf8("priorityLabel"));
        QFont font;
        font.setFamily(QString::fromUtf8("Monospace"));
        priorityLabel->setFont(font);

        horizontalLayout_6->addWidget(priorityLabel);

        priorEdit = new QLineEdit(editwindow);
        priorEdit->setObjectName(QString::fromUtf8("priorEdit"));

        horizontalLayout_6->addWidget(priorEdit);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        complDateLabel = new QLabel(editwindow);
        complDateLabel->setObjectName(QString::fromUtf8("complDateLabel"));
        complDateLabel->setFont(font);

        horizontalLayout_5->addWidget(complDateLabel);

        complDateEdit = new QLineEdit(editwindow);
        complDateEdit->setObjectName(QString::fromUtf8("complDateEdit"));

        horizontalLayout_5->addWidget(complDateEdit);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        creatDateLabel = new QLabel(editwindow);
        creatDateLabel->setObjectName(QString::fromUtf8("creatDateLabel"));
        creatDateLabel->setFont(font);

        horizontalLayout_4->addWidget(creatDateLabel);

        createDateEdit = new QLineEdit(editwindow);
        createDateEdit->setObjectName(QString::fromUtf8("createDateEdit"));

        horizontalLayout_4->addWidget(createDateEdit);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        textLabel = new QLabel(editwindow);
        textLabel->setObjectName(QString::fromUtf8("textLabel"));
        textLabel->setFont(font);

        horizontalLayout_3->addWidget(textLabel);

        textEdit = new QLineEdit(editwindow);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        horizontalLayout_3->addWidget(textEdit);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        contextLabel = new QLabel(editwindow);
        contextLabel->setObjectName(QString::fromUtf8("contextLabel"));
        contextLabel->setFont(font);

        horizontalLayout_2->addWidget(contextLabel);

        contextEdit = new QLineEdit(editwindow);
        contextEdit->setObjectName(QString::fromUtf8("contextEdit"));

        horizontalLayout_2->addWidget(contextEdit);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        projectLabel = new QLabel(editwindow);
        projectLabel->setObjectName(QString::fromUtf8("projectLabel"));
        projectLabel->setFont(font);

        horizontalLayout->addWidget(projectLabel);

        projectEdit = new QLineEdit(editwindow);
        projectEdit->setObjectName(QString::fromUtf8("projectEdit"));

        horizontalLayout->addWidget(projectEdit);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        buttonBox = new QDialogButtonBox(editwindow);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Save);
        buttonBox->setCenterButtons(false);

        horizontalLayout_7->addWidget(buttonBox);


        verticalLayout->addLayout(horizontalLayout_7);


        retranslateUi(editwindow);
        QObject::connect(buttonBox, SIGNAL(accepted()), editwindow, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editwindow, SLOT(reject()));

        QMetaObject::connectSlotsByName(editwindow);
    } // setupUi

    void retranslateUi(QDialog *editwindow)
    {
        editwindow->setWindowTitle(QCoreApplication::translate("editwindow", "Edit", nullptr));
        priorityLabel->setText(QCoreApplication::translate("editwindow", "Priority:       ", nullptr));
        complDateLabel->setText(QCoreApplication::translate("editwindow", "Completion date:", nullptr));
        creatDateLabel->setText(QCoreApplication::translate("editwindow", "Creation date:  ", nullptr));
        textLabel->setText(QCoreApplication::translate("editwindow", "Text:           ", nullptr));
        contextLabel->setText(QCoreApplication::translate("editwindow", "Context tag:    ", nullptr));
        projectLabel->setText(QCoreApplication::translate("editwindow", "Project tag:    ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class editwindow: public Ui_editwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITWINDOW_H
